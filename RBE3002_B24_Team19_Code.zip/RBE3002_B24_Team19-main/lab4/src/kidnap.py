#!/usr/bin/env python3

import rospy
import math
from nav_msgs.msg import Odometry
from geometry_msgs.msg import PoseStamped, PoseWithCovarianceStamped
from geometry_msgs.msg import Twist
from nav_msgs.msg import  Path
from std_srvs.srv import Empty
from typing import Tuple
from tf.transformations import euler_from_quaternion
import tf


class Kidnap:

    def __init__(self):
        """
        Class constructor
        """
        ### Robot Parameters ###
        
        self.roll = 0.0
        self.pitch = 0.0
        self.yaw = 0.0
        self.px = 0
        self.py = 0
        self.pth = 0
        self.cov = 1.0
        self.quat_orig = (0.0, 0.0, 0.0, 0.0)
        self.Settled = False
        ### Initialize node, name it 'lab2'
        
        rospy.init_node('Kidnap')
        self.listener = tf.TransformListener()
        self.GlobalLocalization = rospy.ServiceProxy('global_localization', Empty)
        ### Tell ROS that this node publishes Twist messages on the '/cmd_vel' topic
        self.cmd_vel = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
        ### Tell ROS that this node subscribes to Odometry messages on the '/odom' topic
        ### When a message is received, call self.update_odometry
        rospy.Subscriber('/odom', Odometry, self.update_odometry)
        rospy.Subscriber('/amcl_pose', PoseWithCovarianceStamped, self.updateCov)

      
        self.send_speed(0.0, 0.0)



    def send_speed(self, linear_speed: float, angular_speed: float):
        """
        Sends the speeds to the motors.
        :param linear_speed  [float] [m/s]   The forward linear speed.
        :param angular_speed [float] [rad/s] The angular speed for rotating around the body center.
        """
        ### Make a new Twist message
        msg_cmd_vel = Twist()

        #Linear velocity
        msg_cmd_vel.linear.x = linear_speed
        msg_cmd_vel.linear.y = 0.0
        msg_cmd_vel.linear.z = 0.0

        #Angular velocity
        msg_cmd_vel.angular.x = 0.0
        msg_cmd_vel.angular.y = 0.0
        msg_cmd_vel.angular.z = angular_speed

        #Send  commmand
        ### Publish the message
        self.cmd_vel.publish(msg_cmd_vel)
    
    def rotate(self, angle: float, aspeed: float):
        """
        Rotates the robot around the body center by the given angle.
        :param angle         [float] [rad]   The distance to cover.
        :param angular_speed [float] [rad/s] The angular speed.
        """

        rospy.sleep(0.050)
        prevPth = self.pth
        while True:
            rospy.sleep(0.050)
            currentPth = self.pth
            error = self.angleCheck(angle - (currentPth - prevPth))
            if error > 0:
                self.send_speed(0.0, aspeed)
            else:
                self.send_speed(0.0, -aspeed)
            #print(error)
            if abs(error) < 0.1:
                self.send_speed(0.0, 0.0)
                print('Stopped')
                break

    def updateCov(self, msg):
        cov_matrix = msg.pose.covariance
        covx = cov_matrix[0]
        covy = cov_matrix[7]
        cova = cov_matrix[35]
        self.cov = (covx + covy + cova)/2
        #self.localize()

    def localize(self):
        if self.cov > 0.03 and self.Settled == False:
            self.send_speed(0, 0.5)
            #rospy.loginfo(self.cov)
        elif(self.Settled == False):
            self.send_speed(0, 0.0)
            self.Settled = True
            rospy.loginfo("Job done")

    def update_odometry(self, msg: Odometry):
        """
        Updates the current pose of the robot.
        This method is a callback bound to a Subscriber.
        :param msg [Odometry] The current odometry information.
        """
        self.px = msg.pose.pose.position.x
        self.py = msg.pose.pose.position.y
        quat_orig = msg.pose.pose.orientation
        (roll, pitch, yaw) = euler_from_quaternion([quat_orig.x, quat_orig.y, quat_orig.z, quat_orig.w])
        self.pth = yaw
        trans = [0, 0]
        rot = [0, 0, 0, 0]
        try:
            (trans, rot) = self.listener.lookupTransform('/map', 'base_footprint', rospy.Time(0))
        except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
            pass
        self.px = trans[0]
        self.py = trans[1]
        quat_orig = [rot[0], rot[1], rot[2], rot[3]]
        (roll, pitch, yaw) = euler_from_quaternion(quat_orig)
        self.pth = yaw


    def angleCheck(self, angle:float):
        """
        Checks Angle given to maint a +Pi and -Pi range.
        :param angle         [float] [rad]   The angle to check.
        Returns angle within -Pi and +Pi range.
        """
        if(angle < -math.pi):
            angle += 2 * math.pi
        elif(angle > math.pi):
            angle -= 2 * math.pi
        return angle



    def run(self):
        rate = rospy.Rate(60)
        
        self.GlobalLocalization.call()
        self.rotate(math.pi, 3.0)
        rospy.sleep(1.0)
        self.rotate(math.pi, 3.0)
        rospy.sleep(1.0)
        while not rospy.is_shutdown():
            # Your main loop logic goes here
            # For example, move the robot forward continuously
            self.localize() # Localize
            # Sleep to control the loop rate
            rate.sleep()

        # Stop the robot when the loop is exited
        self.send_speed(0.0, 0.0)
            


        

if __name__ == '__main__':
    Kidnap().run()


