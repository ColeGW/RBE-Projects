#!/usr/bin/env python3

import math
import rospy
from nav_msgs.srv import GetPlan
from nav_msgs.msg import  Path
from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import Odometry
from std_msgs.msg import Empty, Int16
#from typing import Tuple as tuple
#from typing import List as list
from std_msgs.msg import Header
from tf.transformations import euler_from_quaternion
from copy import deepcopy
import subprocess
import tf


class ServiceRequester:

    def __init__(self):
        """
        Class constructor
        """
        ### Robot Parameters ###
        
        self.count = 0
        self.roll = 0.0
        self.pitch = 0.0
        self.yaw = 0.0
        self.px = 0 # 0.4
        self.py = 0 #2.0
        self.pth = 0
        self.quat_orig = (0.0, 0.0, 0.0, 0.0)
        
        self.currPath = Path()
        self.outOfFront = False
        self.frontCount = 0
        self.Home = False
        self.Mapped = False
        ### Initialize node, name it 'serviceRequester'
        rospy.init_node('serviceRequester')
        self.listener = tf.TransformListener()
        ### Tell ROS that this node subscribes to PoseStamped messages on the '/move_base_simple/goal' topic
        ### When a message is received, call self.go_to
        rospy.Subscriber('/reachedEnd', Empty, self.requestFrontier)

        rospy.Subscriber('/frontCount', Int16, self.updateCount)
        ### Tell ROS that this node publishes to Path
        self.aStarPath = rospy.Publisher('/path', Path, queue_size=3)

        self.getOutOfFront = rospy.Publisher('/getOut', Path, queue_size=3)
        ### Tell ROS that this node is a service client for the '/plan_path' service
        self.client = rospy.ServiceProxy('plan_path', GetPlan)
        ### Tell ROS that this node is a service client for the '/update_front' service
        self.update = rospy.ServiceProxy('update_front', GetPlan) 


        self.out = rospy.ServiceProxy('get_out', GetPlan)
        ### Tell ROS that this node subscribes to Odometry messages on the '/odom' topic
        ### When a message is received, call self.update_odometry
        rospy.Subscriber('/odom', Odometry, self.update_odometry)

        self.goal_publisher = rospy.Publisher('move_base_simple/goal', PoseStamped, queue_size=10)

    def sendPathToRobot(self, path: Path):
        """
        Sends the path to the robot
        :param path: The path to send to the robot
        :return: None
        """
        rospy.loginfo("Sending path to robot")
        #print(path)
        for i in range(len(path.poses)):
            self.goal_publisher.publish(path.poses[i])
            #rospy.sleep(1)
        #rospy.sleep(0.05)

    def requestFrontier(self, useless: Empty):
        """
        Request new frontier for robot to go to
        :return Path from robot to frontier
        """
        start = PoseStamped()
        start.header.stamp = rospy.Time.now()
        start.header.frame_id = "start_id"
        start.pose.position.x = self.px
        start.pose.position.y = self.py
        goal = PoseStamped()
        goal.header.stamp = start.header.stamp
        goal.header.frame_id = "goal_id"
        goal.pose.position.x = self.px
        goal.pose.position.y = self.py
        # Wait for the service
        rospy.wait_for_service('plan_path')
        try:
            path = rospy.ServiceProxy('plan_path', GetPlan)
            rospy.loginfo(self.frontCount)
            if(self.frontCount > 0 or self.outOfFront == True and self.Mapped == False):
                self.currPath = path(start, goal, 0.2).plan
                if self.currPath is not None and (len(self.currPath.poses) > 0):
                    self.aStarPath.publish(self.currPath)
                    self.outOfFront = False
                elif(self.Mapped == False):
                    if(self.outOfFront == True):
                        self.Mapped = True
                        goal.header.stamp = rospy.Time.now()
                        goal.pose.position.x = 0.0 #0.4
                        goal.pose.position.y = 0.0 #2.0
                        goal.pose.position.z = 0.0
                        rospy.loginfo("Going Home")
                        self.currPath = path(start, goal, 0.2).plan
                        self.aStarPath.publish(self.currPath)
                    else:
                        self.getOut(start)
                        self.outOfFront = True
            elif(self.Mapped == True):
                map_name = "lab_run"
                save_location = "/home/colewelcher/catkin_ws/src/RBE3002_B24_Team19/lab4/map/"
                command = ["rosrun", "map_server", "map_saver", "-f", save_location + map_name]
                subprocess.run(command)

                    
            """
            elif(self.outOfFront == False):
                self.getOut(start)
                self.outOfFront = True
            
            else:
                ## Go Home
                rospy.loginfos("Going Home")
                #Save Map
                #self.getOut(start)
                goal.header.stamp = rospy.Time.now()
                goal.pose.position.x = 0.4
                goal.pose.position.y = 2.0
                goal.pose.position.z = 0
                rospy.loginfo(start.pose.position, goal.pose.position)
                #self.currPath = path(start, goal, 0.2).plan
                #self.aStarPath.publish(self.currPath)
                self.Home = True
                rospy.loginfo("Map has been saved")
            """
            #self.sendPathToRobot(self.currPath)
        except rospy.ServiceException as e:
            print("Service call failed: %s"%e)

    def updateCount(self, msg: Int16):
        self.frontCount = msg.data

    def update_odometry(self, msg: Odometry):
        """
        Updates the current pose of the robot.
        This method is a callback bound to a Subscriber.
        :param msg [Odometry] The current odometry information.
        """
        self.px = msg.pose.pose.position.x
        self.py = msg.pose.pose.position.y
        quat_orig = msg.pose.pose.orientation
        (roll, pitch, yaw) = euler_from_quaternion([quat_orig.x, quat_orig.y, quat_orig.z, quat_orig.w])
        self.pth = yaw
        trans = [0, 0]
        rot = [0, 0, 0, 0]
        try:
            (trans, rot) = self.listener.lookupTransform('/map', 'base_footprint', rospy.Time(0))
        except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
            pass
        self.px = trans[0]
        self.py = trans[1]
        quat_orig = [rot[0], rot[1], rot[2], rot[3]]
        (roll, pitch, yaw) = euler_from_quaternion(quat_orig)
        self.pth = yaw


    def getOut(self, start: PoseStamped):
        """
        Gets the robot out of the c-space
        :param start: The starting position of the robot
        :return: None
        """
        rospy.loginfo("Getting out of C-space")
        rospy.wait_for_service('get_out')
        #rospy.loginfo("line 151")
        try:
            #rospy.loginfo("line 154")
            path = rospy.ServiceProxy('get_out', GetPlan)
            #rospy.loginfo("line 153")
            getOutPath = path(start, start, 0.2).plan
            #rospy.loginfo(getOutPath)
            self.getOutOfFront.publish(getOutPath)
            #rospy.sleep(0.05)
        except rospy.ServiceException as e:
            print("Service call failed: %s"%e)   
        
    
    def updateFront(self):
        """
        Updates the frontier of the map
        :return: None
        """
        rospy.loginfo("Updating the frontier")
        rospy.wait_for_service('update_front')
        try:
            start = PoseStamped()
            start.pose.position.x = self.px
            start.pose.position.y = self.py
            start.header.stamp = rospy.Time.now()
            start.header.frame_id = "start_pose"
            start.pose.position.z = 0
            goal = start
            goal.header.stamp = rospy.Time.now()
            goal.header.frame_id = "goal_pose"
            frontUpdate = rospy.ServiceProxy('update_front', GetPlan)
            hold = frontUpdate(start, goal, 0.2).plan
            self.frontCount = hold.poses[0].pose.position.x
        except rospy.ServiceException as e:
            print("Service call failed: %s"%e)

    def run(self):
        self.updateFront()
        rospy.loginfo(self.frontCount)
        self.requestFrontier(Empty)
        rate = rospy.Rate(20)
        rospy.spin()
        


if __name__ == '__main__':
    ServiceRequester().run()






















    """

        Request new frontier for robot to go to
        :return Path from robot to frontier
    """
    """
    #self.updateFront()
    rospy.loginfo("Received service request at position {msg.pose.position}")
    start = PoseStamped()
    start.header.stamp = rospy.Time.now()
    start.header.frame_id = "start_id"
    start.pose.position.x = self.px
    start.pose.position.y = self.py
    start.pose.position.z = 0
    goal = PoseStamped()
    goal.header.stamp = rospy.Time.now()
    goal.header.frame_id = "goal_id"
    goal.pose.position.x = self.px
    goal.pose.position.y = self.px
    goal.pose.position.z = 0
    # Wait for the service
    rospy.wait_for_service('plan_path')
    try:
        path = rospy.ServiceProxy('plan_path', GetPlan)
        if(self.Mapped == False):
            self.currPath = path(start, goal, 0.2).plan
            rospy.loginfo(self.frontCount)
            if self.currPath is not None and (len(self.currPath.poses) > 0 and self.frontCount > 0):
                #holder = list(reversed(self.PrevPath.poses))
                #if set(holder).issubset(self.currPath.poses) or set(self.currPath.poses).issubset(holder):
                self.aStarPath.publish(self.currPath)
                self.PrevPath = path(start, goal, 0.2).plan
                self.outOfFront = False
            elif(self.outOfFront == False):
                self.getOut(start)
                self.outOfFront = True
                rospy.sleep(1)
            else:
                self.Mapped = True            
        elif(self.Home == False):
            rospy.loginfo("Going Home")
            #Save Map
            goal.header.stamp = rospy.Time.now()
            goal.pose.position.x = 0.4
            goal.pose.position.y = 2.0
            goal.pose.position.z = 0
            self.currPath = path(start, goal, 0.2).plan
            self.aStarPath.publish(self.currPath)
            self.Home = True
            rospy.loginfo("Map has been saved")
        
        rospy.sleep(2)
"""