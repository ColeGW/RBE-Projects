#!/usr/bin/env python3

import rospy
import math
from nav_msgs.msg import Odometry
from geometry_msgs.msg import PoseStamped, PoseWithCovarianceStamped
from geometry_msgs.msg import Twist
from nav_msgs.msg import  Path
from std_msgs.msg import Empty
from typing import Tuple
from tf.transformations import euler_from_quaternion
import tf

class Lab2:

    def __init__(self):
        """
        Class constructor
        """
        ### Robot Parameters ###
        
        self.roll = 0.0
        self.pitch = 0.0
        self.yaw = 0.0
        self.px = 0
        self.py = 0
        self.pth = 0
        self.quat_orig = (0.0, 0.0, 0.0, 0.0)
        self.lad = 0.22
        ### Initialize node, name it 'lab2'
        rospy.init_node('lab2')
        self.listener = tf.TransformListener()
        ### Tell ROS that this node publishes Twist messages on the '/cmd_vel' topic
        self.cmd_vel = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
        ### Tell ROS that this node subscribes to Odometry messages on the '/odom' topic
        ### When a message is received, call self.update_odometry
        rospy.Subscriber('/odom', Odometry, self.update_odometry)
        #rospy.Subscriber('/amcl_pose', PoseWithCovarianceStamped, self.update_odometryBasedOnAmcl)
        ### Tell ROS that this node subscribes to PoseStamped messages on the '/move_base_simple/goal' topic
        ### When a message is received, call self.go_to
        self.reached = rospy.Publisher('/reachedEnd', Empty, queue_size=10)
      #  rospy.Subscriber('move_base_simple/goal', PoseStamped, self.p_go_to)

        rospy.Subscriber('/path', Path, self.path)
        rospy.Subscriber('/getOut', Path, self.pathOut)
        self.send_speed(0.0, 0.0)


    def send_speed(self, linear_speed: float, angular_speed: float):
        """
        Sends the speeds to the motors.
        :param linear_speed  [float] [m/s]   The forward linear speed.
        :param angular_speed [float] [rad/s] The angular speed for rotating around the body center.
        """
        ### Make a new Twist message
        msg_cmd_vel = Twist()

        #Linear velocity
        msg_cmd_vel.linear.x = linear_speed
        msg_cmd_vel.linear.y = 0.0
        msg_cmd_vel.linear.z = 0.0

        #Angular velocity
        msg_cmd_vel.angular.x = 0.0
        msg_cmd_vel.angular.y = 0.0
        msg_cmd_vel.angular.z = angular_speed

        #Send  commmand
        ### Publish the message
        self.cmd_vel.publish(msg_cmd_vel)
    """
    def angleCheck(self, angle:float):
        
        Checks Angle given to maint a +Pi and -Pi range.
        :param angle         [float] [rad]   The angle to check.
        Returns angle within -Pi and +Pi range.
        
        angle = angle % (2 * math.pi)
        if(angle < -math.pi):
            angle = math.pi - (angle % math.pi)
        elif(angle > math.pi):
            angle =  -math.pi + (angle % math.pi) 
        return angle
    """
        
    def drive(self, distance: float, linear_speed: float):
        """
        Drives the robot in a straight line.
        :param distance     [float] [m]   The distance to cover.
        :param linear_speed [float] [m/s] The forward linear speed.
        """
        prevPx = self.px
        prevPy = self.py
        PrevPth = self.pth


        while True:
           rospy.sleep(0.0050)
           self.send_speed(linear_speed, 0.0)
           #print(self.px, self.py, self.pth)

           error = distance - (math.sqrt((self.px-prevPx)**2+(self.py-prevPy)**2))
           if error < 0.1:
                self.send_speed(0.0, 0.0)
                print('Stopped')
                break



    def rotate(self, angle: float, aspeed: float):
        """
        Rotates the robot around the body center by the given angle.
        :param angle         [float] [rad]   The distance to cover.
        :param angular_speed [float] [rad/s] The angular speed.
        """

        rospy.sleep(0.005)
        prevPth = self.pth
        while True:
            rospy.sleep(0.005)
            currentPth = self.pth
            error = self.angleCheck(angle - (currentPth - prevPth))
            if error > 0:
                self.send_speed(0.0, aspeed)
            else:
                self.send_speed(0.0, -aspeed)

            if abs(error) < 0.1:
                self.send_speed(0.0, 0.0)
                print('Stopped')
                break

    def pure_pursuit(self, waypoints: [], currSpeed: float) -> Tuple[float, float]:
        '''
        Looks ahead a certain distance and calculates the heading error and speed to send to the robot
        :param waypoints    [list] [m]   The waypoints to follow.
        :param currSpeed    [float] [m/s] The current speed of the robot.

        :return heading_error [float] [rad] The heading error to send to the robot.
        :return speed         [float] [m/s] The speed to send to the robot.
        '''
        lad = self.lad #Look ahead distance
        # if(len(waypoints) < 25):
        #     lad = 0.1
        distances = [math.sqrt((waypoints[i][0] - self.px)**2 + (waypoints[i][1] - self.py)**2) for i in range(len(waypoints))]
        closest_index = distances.index(min(distances))
        total_distance = 0
        for i in range(closest_index, len(waypoints)):
            total_distance += math.sqrt((waypoints[i][0] - waypoints[i-1][0])**2 + (waypoints[i][1] - waypoints[i-1][1])**2)
            if total_distance >= lad:
                break
        if i == len(waypoints) - 1:
            alpha = (lad - (total_distance - math.sqrt((waypoints[i][0] - waypoints[i-1][0])**2 + (waypoints[i][1] - waypoints[i-1][1])**2))) / math.sqrt((waypoints[i][0] - waypoints[i-1][0])**2 + (waypoints[i][1] - waypoints[i-1][1])**2)
            target_point = tuple(((1- alpha) * waypoints[i-1][0] + alpha * waypoints[i][0], (1- alpha) * waypoints[i-1][1] + alpha * waypoints[i][1]))
        else:
            target_point = waypoints[i]
        heading = self.pth
        angle_to_target = math.atan2(target_point[1] - self.py, target_point[0] - self.px)
        heading_error = self.angleCheck(angle_to_target - heading)
        speedCoeff = 0.15
        if(abs(heading_error) < math.pi/36):
            speed = speedCoeff * (1 - 0.9 * abs(heading_error / math.pi))
            self.lad = speed * lad
        else:
            speed = 0.02
            self.lad = speed * lad
            if(abs(heading_error) > math.pi/2):
                heading_error = heading_error / abs(heading_error) * math.pi/2
        return (1.0 * heading_error), speed

    def path(self, msg: Path):
        reached = False
        waypoints = []
        for pose in msg.poses:
            if pose.pose.position.x:
                waypoints.append([pose.pose.position.x, pose.pose.position.y])
        #print(waypoints)
        waypoints.pop(0)
        if(len(waypoints) <= 0):
            return
        goal = waypoints[-1]
        speed = 0.0
        finalGoal = 0.075
        while not reached:
            rospy.sleep(0.0050)
            heading_error, speed = self.pure_pursuit(waypoints, speed)
            #rospy.loginfo('Speed: ' + str(speed))
            if math.sqrt((waypoints[0][0] - self.px)**2 + (waypoints[0][1] - self.py)**2) < 0.075:
                waypoints.pop(0)
                #rospy.loginfo('Waypoint reached')
            rospy.loginfo(f"Speed: {speed}, Heading Error: {heading_error}")
            self.send_speed(speed, heading_error)
            if math.sqrt((goal[0] - self.px)**2 + (goal[1] - self.py)**2) < finalGoal or len(waypoints) == 1:
                reached = True
        #rospy.loginfo('Reached end of path')
        rospy.sleep(1)
        self.reached.publish()
        self.send_speed(0.0, 0.0)

    def pathOut(self, msg: Path):
        reached = False
        waypoints = []
        for pose in msg.poses:
            if pose.pose.position.x:
                waypoints.append([pose.pose.position.x, pose.pose.position.y])
        #print(waypoints)
        waypoints.pop(0)
        goal = waypoints[-1]
        speed = 0.0
        finalGoal = 0.05
        idkyet = 0.05
        while not reached:
            rospy.sleep(0.005)
            heading_error, speed = self.pure_pursuit(waypoints, speed)
            #rospy.loginfo('Speed: ' + str(speed))
            if math.sqrt((waypoints[0][0] - self.px)**2 + (waypoints[0][1] - self.py)**2) < idkyet:
                waypoints.pop(0)
                #rospy.loginfo('Waypoint reached')
            self.send_speed(speed, heading_error)
            if math.sqrt((goal[0] - self.px)**2 + (goal[1] - self.py)**2) < finalGoal or len(waypoints) == 1:
                reached = True
        #rospy.loginfo('Reached end of path')
        self.reached.publish()
        self.send_speed(0.0, 0.0)



    def p_go_to(self, msg: PoseStamped):
        """
        Calls rotate(), drive(), and rotate() to attain a given pose.
        This method is a callback bound to a Subscriber.
        :param msg [PoseStamped] The target pose.
        """
    
        #Constans:

        disKp = 0.5
        angKp = 0.7
        angSpeed = 0
        disSpeed = 0

        #Store target Pose
        targetOrientation = msg.pose

        #Calculate initial rotation to pose and target X & Y
        targetX = targetOrientation.position.x
        targetY = targetOrientation.position.y
        targetAngle = euler_from_quaternion((targetOrientation.orientation.x, targetOrientation.orientation.y, targetOrientation.orientation.z, targetOrientation.orientation.w))[2] #Yaw angle
        deltaX = targetX - self.px
        deltaY = targetY - self.py
        lineUp = 0
        lineUp = math.atan2(deltaY, deltaX)
 
        #Account for larger then 180 or less than -180
        targetAngle = self.angleCheck(targetAngle)
        lineUp = self.angleCheck(lineUp)

        print(targetX, targetY, targetAngle, lineUp)
        #Rotate to correct orientation towards target pose
        while True:
            rospy.sleep(0.0050)
            currentPth = self.pth

            angleError = self.angleCheck(lineUp - currentPth)
            angSpeed = angKp * angleError
            self.send_speed(0.0, angSpeed)
            if abs(angleError) < math.pi/30:
                self.send_speed(0.0, 0.0)
                break

        #P Start For Distance
        while True:
            rospy.sleep(0.0050)
            #Deltas
            deltaX = targetX - self.px
            deltaY = targetY - self.py

            #Angle to Point Towards Target Position Error Calculaion

            turn_angle = math.atan2(deltaY, deltaX)
            heading_error = self.angleCheck(turn_angle - self.pth)        
            angSpeed = angKp * heading_error

            #Distance to Point Towards Target Position Error Calculaion
            distanceError = math.sqrt((targetX - self.px)**2 + (targetY - self.py)**2)
            disSpeed = disKp * distanceError #+ disKi * integralDistance + disKd * distanceDerivative
            #Cap Distance Speed to 0.5 and -0.5
            if disSpeed > 1:
                disSpeed = 1
            elif disSpeed < -1:
                disSpeed = -1

            #Send Speed
            self.send_speed(disSpeed, angSpeed)

            #Stop Error For Distance 

            if abs(distanceError) < 0.02:

                self.send_speed(0.0, 0.0)
                break
        
        #Heading Angle Fix If got to Point but Angle Error isstill there
        """
        while True:
            rospy.sleep(0.050)
            currentPth = self.pth
            angleError = targetAngle - currentPth

            #Handle over 180 and under -180
            angleError = self.angleCheck(angleError)
            angSpeed = angKp * angleError

            self.send_speed(0.0, angSpeed)

            if abs(angleError) < 0.05:
                self.send_speed(0.0, 0.0)
                #print("Stopped") DEBUGGING PURPOSES
                break
        """
        self.send_speed(0.0, 0.0)


    def tdt_go_to(self, msg: PoseStamped):
        """
        Calls rotate(), drive(), and rotate() to attain a given pose.
        This method is a callback bound to a Subscriber.
        :param msg [PoseStamped] The target pose.
        """
        thetaPoint = math.atan2(msg.pose.position.y - self.py, msg.pose.position.x - self.px)
        thetaError = thetaPoint - self.pth


        if(thetaError > math.pi):
            thetaError = thetaError - 2*math.pi
        elif (thetaError < -math.pi):
            thetaError = thetaError + 2*math.pi

        print(math.degrees(thetaError))
        self.rotate(thetaError, 0.4)
        self.drive(math.sqrt((msg.pose.position.x - self.px)**2 + (msg.pose.position.y - self.py)**2), 0.25)
        self.rotate(math.atan2(msg.pose.orientation.z, msg.pose.orientation.w), 0.4)
        print("Reached goal!")


    def update_odometry(self, msg: Odometry):
        """
        Updates the current pose of the robot.
        This method is a callback bound to a Subscriber.
        :param msg [Odometry] The current odometry information.
        """
        self.px = msg.pose.pose.position.x
        self.py = msg.pose.pose.position.y
        quat_orig = msg.pose.pose.orientation
        (roll, pitch, yaw) = euler_from_quaternion([quat_orig.x, quat_orig.y, quat_orig.z, quat_orig.w])
        self.pth = yaw
        trans = [0, 0]
        rot = [0, 0, 0, 0]
        try:
            (trans, rot) = self.listener.lookupTransform('/map', 'base_footprint', rospy.Time(0))
        except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
            pass
        self.px = trans[0]
        self.py = trans[1]
        quat_orig = [rot[0], rot[1], rot[2], rot[3]]
        (roll, pitch, yaw) = euler_from_quaternion(quat_orig)
        self.pth = yaw

        



    def smooth_drive(self, distance: float, linear_speed: float):
        """
        Drives the robot in a straight line by changing the actual speed smoothly.
        :param distance     [float] [m]   The distance to cover.
        :param linear_speed [float] [m/s] The maximum forward linear speed.
        """
        ### EXTRA CREDIT
        # TODO
        pass # delete this when you implement your code

    def angleCheck(self, angle:float):
        """
        Checks Angle given to maint a +Pi and -Pi range.
        :param angle         [float] [rad]   The angle to check.
        Returns angle within -Pi and +Pi range.
        """
        if(angle < -math.pi):
            angle += 2 * math.pi
        elif(angle > math.pi):
            angle -= 2 * math.pi
        return angle



    def run(self):
        #self.rotate(1, 100)
        rate = rospy.Rate(20)
        rospy.spin()

if __name__ == '__main__':
    Lab2().run()
