#!/usr/bin/env python3

import math
import rospy
from nav_msgs.srv import GetPlan
from nav_msgs.msg import  Path
from geometry_msgs.msg import PoseWithCovarianceStamped, PoseStamped
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion
import tf

#from typing import Tuple as tuple
#from typing import List as list



class ServiceRequester:

    def __init__(self):
        """
        Class constructor
        """
        
        ### Robot Parameters ###
        self.roll = 0.0
        self.pitch = 0.0
        self.yaw = 0.0
        self.px = 0
        self.py = 0
        self.pth = 0
        self.quat_orig = (0.0, 0.0, 0.0, 0.0)
        ### Initialize node, name it 'lab2'
        rospy.init_node('serviceRequester')
        self.listener = tf.TransformListener()
        ### Tell ROS that this node subscribes to PoseStamped messages on the '/move_base_simple/goal' topic
        ### When a message is received, call self.go_to
        rospy.Subscriber('move_base_simple/goal', PoseStamped, self.requestService)
        ### Tell ROS that this node subscribes to Odometry messages on the '/odom' topic
        rospy.Subscriber('/odom', Odometry, self.update_odometry)
        ### When a message is received, call self.update_odometry
        #rospy.Subscriber('/odom', Odometry, self.update_odometry)
        ### Tell ROS that this node publishes to Path
        self.aStarPath = rospy.Publisher('/path', Path)
        self.client = rospy.ServiceProxy('plan_path', GetPlan)

        self.goal_publisher = rospy.Publisher('move_base_simple/goal', PoseStamped, queue_size=10)
        #rospy.Subscriber('/odom', Odometry, self.update_angle)


    def sendPathToRobot(self, path: Path):
        """
        Sends the path to the robot
        :param path: The path to send to the robot
        :return: None
        """
        rospy.loginfo("Sending path to robot")
        print(path)
        for i in range(len(path.poses)):
            self.goal_publisher.publish(path.poses[i])
            rospy.sleep(2)

    def requestService(self, msg: PoseWithCovarianceStamped):
        rospy.loginfo("Received service request at position {msg.pose.position}")
        start = PoseStamped()
        
        start.pose.position.x = self.px
        start.pose.position.y = self.py
        start.pose.position.z = self.pth
        rospy.loginfo(self.px)
        rospy.loginfo(self.py)
        rospy.loginfo(self.pth)
        # Wait for the service
        #self.client.wait_for_service(5)
        #PathMsg = self.client.call(start, msg, 0.05)
        rospy.wait_for_service('plan_path')
        try:
            path = rospy.ServiceProxy('plan_path', GetPlan)
            self.aStarPath.publish(path(start, msg, 0.05).plan)
        except rospy.ServiceException as e:
            print("Service call failed: %s"%e)
        # print(PathMsg)
        
       # self.sendPathToRobot(PathMsg.plan)

    """
    def update_odometry(self, msg: PoseWithCovarianceStamped) :
        
        Updates the current pose of the robot.
        This method is a callback bound to a Subscriber.
        :param msg [Odometry] The current odometry information.
       
        amcl_pose = msg.pose.pose
        self.px = amcl_pose.position.x
        self.py = amcl_pose.position.y
        self.pth = euler_from_quaternion([amcl_pose.orientation.x, amcl_pose.orientation.y, amcl_pose.orientation.z, amcl_pose.orientation.w])[2]
        rospy.loginfo("Robot Pose: x={}, y={}, theta={}".format(self.px, self.py, self.pth))
    """
    
    def update_odometry(self, msg: Odometry):
        """
        Updates the current pose of the robot.
        This method is a callback bound to a Subscriber.
        :param msg [Odometry] The current odometry information.
        """
        self.px = msg.pose.pose.position.x
        self.py = msg.pose.pose.position.y
        quat_orig = msg.pose.pose.orientation
        (roll, pitch, yaw) = euler_from_quaternion([quat_orig.x, quat_orig.y, quat_orig.z, quat_orig.w])
        self.pth = yaw
        trans = [0, 0]
        rot = [0, 0, 0, 0]
        try:
            (trans, rot) = self.listener.lookupTransform('/map', 'base_footprint', rospy.Time(0))
        except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
            pass
        self.px = trans[0]
        self.py = trans[1]
        quat_orig = [rot[0], rot[1], rot[2], rot[3]]
        (roll, pitch, yaw) = euler_from_quaternion(quat_orig)
        self.pth = yaw


    def update_angle(self, msg: PoseStamped):
        quat_orig = msg.pose.pose.orientation
        #(roll, pitch, yaw) = euler_from_quaternion([quat_orig.x, quat_orig.y, quat_orig.z, quat_orig.w])
        #self.pth = yaw

    def run(self):
        rate = rospy.Rate(10)
        rospy.spin()

if __name__ == '__main__':
    ServiceRequester().run()

"""
 def requestService(self, msg: PoseStamped):
        rospy.loginfo("Received service request at position {msg.pose.position}")
        start = PoseStamped()
        start.pose.position.x = 0
        start.pose.position.y = 0
        start.pose.position.z = 0

        # Wait for the service
        #self.client.wait_for_service(5)
        PathMsg = self.client.call(start, msg, 0.05)
        # print(PathMsg)
        self.aStarPath.publish(PathMsg.plan)
       # self.sendPathToRobot(PathMsg.plan)
    
"""





