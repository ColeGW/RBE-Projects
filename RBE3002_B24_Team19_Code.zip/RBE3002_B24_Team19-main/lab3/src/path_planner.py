#!/usr/bin/env python3

import math
import rospy
import numpy as np
from typing import Tuple as tuple
from typing import List as list
import numpy as np
from nav_msgs.srv import GetPlan, GetMap
from nav_msgs.msg import GridCells, OccupancyGrid, Path
from geometry_msgs.msg import Point, Pose, PoseStamped
from typing import Tuple as tuple
from typing import List as list
from priority_queue import PriorityQueue
from collections import deque
from std_msgs.msg import Int16

class PathPlanner:


    
    def __init__(self):
        """
        Class constructor
        """
        ### REQUIRED CREDIT
        ## Initialize the node and call it "path_planner"
        rospy.init_node("path_planner")
        self.check = False
        """
        Lab 3 Code
        ## Create a new service called "plan_path" that accepts messages of
        ## type GetPlan and calls self.plan_path() when a message is received
        rospy.Service("plan_path", GetPlan, self.plan_path)
        """
        ## Init CSpace ##
        self.cspaceholder = OccupancyGrid()
        self.cspaceGridCells = GridCells()
         ### Tell ROS that this node subscribes to map messages on the '/map' topic
        ### When a message is received, call self.cspaceCalc
        #rospy.Subscriber('/map', OccupancyGrid, self.formCspace) ##self.formCspace
        rospy.Subscriber('/map', OccupancyGrid, self.updateCspace) 


        #self.frontCount = rospy.Publisher("/frontCount", Int16)
        ## Create a new service called "plan_path" that accepts messages of
        ## type GetPlan and calls self.plan_path() when a message is received
        rospy.Service("plan_path", GetPlan, self.plan_path)
        ## Create a new service called "update_front" that accepts messages of
        ## type tuple[] and calls self.update_front() when a message is received
        #rospy.Service("update_front", GetPlan, self.update_front)


        #rospy.Service("get_out", GetPlan, self.getOut)
        ## Create a publisher for the C-space (the enlarged occupancy grid)
        ## The topic is "/path_planner/cspace", the message type is GridCells
        self.Cspace = rospy.Publisher("/path_planner/cspace", GridCells, queue_size=3)
        ## Create a publisher for the frotniers (Between Known and Unknown)
        ## The topic is "/path_planner/frontiers", the message type is GridCells
        self.Frontiers = rospy.Publisher("/path_planner/frontiers", GridCells, queue_size=3)
        ## Create publishers for A* (expanded cells, frontier, ...)
        ## Choose a the topic names, the message type is GridCells
        self.Astar = rospy.Publisher("path_planner/astar", GridCells, queue_size=3)
        self.Wave = rospy.Publisher("path_planner/wave", GridCells, queue_size=3)
        ## Initialize the request counter
        self.requestCounter = 0 #What is this for?

        #self.reached = rospy.Publisher('/reachedEnd', Empty, queue_size=10)
        ### Tell ROS that this node subscribes to map messages on the '/map' topic
        ### When a message is received, call self.cspaceCalc
        #rospy.Subscriber('/map', OccupancyGrid, self.formCspace) ##self.formCspace
        #rospy.Subscriber('/map', OccupancyGrid, self.updateCspace) 
        ## Sleep to allow roscore to do some housekeeping
        rospy.sleep(1.0)
        rospy.loginfo("Path planner node ready")
       



    @staticmethod
    def grid_to_index(mapdata: OccupancyGrid, p: tuple[int, int]) -> int:
        """
        Returns the index corresponding to the given (x,y) coordinates in the occupancy grid.
        :param p [(int, int)] The cell coordinate.
        :return  [int] The index.
        """
        ### REQUIRED CREDIT
        
        return p[0] + p[1] * mapdata.info.width



    @staticmethod
    def euclidean_distance(p1: tuple[float, float], p2: tuple[float, float]) -> float:
        """
        Calculates the Euclidean distance between two points.
        :param p1 [(float, float)] first point.
        :param p2 [(float, float)] second point.
        :return   [float]          distance.
        """
        ### REQUIRED CREDIT
        return math.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)

    @staticmethod
    def grid_to_world(mapdata: OccupancyGrid, p: tuple[int, int]) -> Point:
        """
        Transforms a cell coordinate in the occupancy grid into a world coordinate.
        :param mapdata [OccupancyGrid] The map information.
        :param p [(int, int)] The cell coordinate.
        :return        [Point]         The position in the world.
        """
        ### REQUIRED CREDIT
        origin = mapdata.info.origin.position
        resolution = mapdata.info.resolution
        x = p[0]
        y = p[1]
        x_world = origin.x + x * resolution + resolution/2
        y_world = origin.y + y * resolution + resolution/2
        return Point(x=x_world, y=y_world)
        
    @staticmethod
    def world_to_grid(mapdata: OccupancyGrid, wp: Point) -> tuple[int, int]:
        """
        Transforms a world coordinate into a cell coordinate in the occupancy grid.
        :param mapdata [OccupancyGrid] The map information.
        :param wp      [Point]         The world coordinate.
        :return        [(int,int)]     The cell position as a tuple.
        """
        ### REQUIRED CREDIT
        origin = mapdata.info.origin.position
        resolution = mapdata.info.resolution
        x = wp.x
        y = wp.y
        if resolution == 0:
            resolution = 0.02
        x_grid = (x - origin.x) / resolution
        y_grid = (y - origin.y) / resolution
        return (int(x_grid), int(y_grid))


        
    @staticmethod
    def path_to_poses(mapdata: OccupancyGrid, path: list[tuple[int, int]]) -> list[PoseStamped]:
        """
        Converts the given path into a list of PoseStamped.
        :param mapdata [OccupancyGrid] The map information.
        :param  path   [[(int,int)]]   The path as a list of tuples (cell coordinates).
        :return        [[PoseStamped]] The path as a list of PoseStamped (world coordinates).
        """
        ### REQUIRED CREDIT
        rospy.loginfo("Converting path to poses")
        pathMsg = Path()
        pathMsg.header = mapdata.header
        for i in range(0, len(path)):
            worldPts = PathPlanner.grid_to_world(mapdata, path[i])
            point = PoseStamped()
            point.pose.position = worldPts
            pathMsg.poses.append(point)
        return pathMsg
        
    @staticmethod
    def is_cell_walkable(mapdata:OccupancyGrid, p: tuple[int, int]) -> bool:
        """
        A cell is walkable if all of these conditions are true:
        1. It is within the boundaries of the grid;
        2. It is free (not unknown, not occupied by an obstacle)
        :param mapdata [OccupancyGrid] The map information.
        :param p       [(int, int)]    The coordinate in the grid.
        :return        [bool]          True if the cell is walkable, False otherwise
        """
        ### REQUIRED CREDIT =
        x = p[0]
        y = p[1]
        index = PathPlanner.grid_to_index(mapdata, p)
        if (p[0] < 0 or p[0] > mapdata.info.width-1 or p[1] < 0 or p[1] > mapdata.info.width-1):
            return False
        if(mapdata.data[index] == 0):
                return True
        return False
    
    @staticmethod
    def isCellIn(mapdata:OccupancyGrid, p: tuple[int, int]) -> bool:
        """
        A cell is walkable if all of these conditions are true:
        1. It is within the boundaries of the grid;
        2. It is free (not unknown, not occupied by an obstacle)
        :param mapdata [OccupancyGrid] The map information.
        :param p       [(int, int)]    The coordinate in the grid.
        :return        [bool]          True if the cell is walkable, False otherwise
        """
        ### REQUIRED CREDIT =
        x = p[0]
        y = p[1]
        index = PathPlanner.grid_to_index(mapdata, p)
        if (p[0] < 0 or p[0] > mapdata.info.width-1 or p[1] < 0 or p[1] > mapdata.info.width-1):
            return False
        return True

    @staticmethod
    def neighbors_of_4(mapdata: OccupancyGrid, p: tuple[int, int]) -> list[tuple[int, int]]:
        """
        Returns the walkable 4-neighbors cells of (x,y) in the occupancy grid.
        :param mapdata [OccupancyGrid] The map information.
        :param p       [(int, int)]    The coordinate in the grid.
        :return        [[(int,int)]]   A list of walkable 4-neighbors.
        """
        ### REQUIRED CREDIT
        x = p[0]
        y = p[1]
        neighbors = []
        if(PathPlanner.is_cell_walkable(mapdata, (x+1, y))):
            neighbors.append((x+1, y))
        if(PathPlanner.is_cell_walkable(mapdata, (x-1, y))):
            neighbors.append((x-1, y))
        if(PathPlanner.is_cell_walkable(mapdata, (x, y+1))):
            neighbors.append((x, y+1))
        if(PathPlanner.is_cell_walkable(mapdata, (x, y-1))):
            neighbors.append((x, y-1))
        return neighbors

    @staticmethod
    def neighbors_of_8(mapdata: OccupancyGrid, p: tuple[int, int]) -> list[tuple[int, int]]:
        """
        Returns the walkable 8-neighbors cells of (x,y) in the occupancy grid.
        :param mapdata [OccupancyGrid] The map information.
        :param p       [(int, int)]    The coordinate in the grid.
        :return        [[(int,int)]]   A list of walkable 8-neighbors.
        """
        ### REQUIRED CREDIT
        x = p[0]
        y = p[1]
        neighbors = []
        for i in range(-1 , 2):
            for j in range(-1 , 2):
                if(PathPlanner.is_cell_walkable(mapdata, (x + i, y + j))):
                    neighbors.append((x+i, y+j))
        return neighbors    

    @staticmethod
    def neighbors(mapdata: OccupancyGrid, p: tuple[int, int]) -> list[tuple[int, int]]:
        """
        Returns the walkable 8-neighbors cells of (x,y) in the occupancy grid.
        :param mapdata [OccupancyGrid] The map information.
        :param p       [(int, int)]    The coordinate in the grid.
        :return        [[(int,int)]]   A list of walkable 8-neighbors.
        """
        ### REQUIRED CREDIT
        x = p[0]
        y = p[1]
        neighbors = []
        for i in range(-1 , 2):
            for j in range(-1 , 2):
                if(PathPlanner.isCellIn(mapdata, (x + i, y + j)) and (i != 0 or y != 0)):
                    neighbors.append((x+i, y+j))
        return neighbors    

    @staticmethod
    def request_map() -> OccupancyGrid:
        """
        Requests the map from the map server.
        :return [OccupancyGrid] The grid if the service call was successful,
                                None in case of error.
        """
        rospy.loginfo("Requesting the map")
        rospy.wait_for_service("static_map")
        try:
            static_map = rospy.ServiceProxy("static_map", GetMap)
            response = static_map()
            rospy.loginfo("Map Recieved")
            return response.map
        except rospy.ServiceException as e:
            rospy.logerr("Service call failed: %s" % e)
            return None
        
    """
    ### Testing Purposes ###
    def formCspace(self, mapdata: OccupancyGrid) -> OccupancyGrid:
        cspace = self.calc_cspace(mapdata, 3)
        start = PathPlanner.world_to_grid(mapdata, Point(x=0, y=0))
        #print(start)
        #print(start)
        #print(PathPlanner.grid_to_world(mapdata, start))
        #print(PathPlanner.grid_to_index(mapdata, start))
        #print(PathPlanner.index_to_grid(PathPlanner.grid_to_index(mapdata, start)))
        self.frontierDetection(cspace, start)
`   """

    def updateCspace(self, mapdata: OccupancyGrid):
        """
        
        Calcs calc_cspace and sets it to the global cspace variable
        :returns none
        """
        self.cspaceholder = self.calc_cspace(mapdata, 4) # 8 for sim
        
    def calc_cspace(self, mapdata: OccupancyGrid, padding: int) -> OccupancyGrid:
        """
        Calculates the C-Space, i.e., makes the obstacles in the map thicker.
        Publishes the list of cells that were added to the original map.
        :param mapdata [OccupancyGrid] The map data.
        :param padding [int]           The number of cells around the obstacles.
        :return        [OccupancyGrid] The C-Space.
        """
        rospy.loginfo("Calculating C-Space")

        
        cspace = OccupancyGrid()
        cspace.header = mapdata.header
        cspace.info = mapdata.info
        cspace.info.origin = mapdata.info.origin
        cspace.info.resolution = mapdata.info.resolution
        cspace.data = [0] * len(mapdata.data)

        #GridCells to Publish
        newGridCells = GridCells()
        ## Inflate the obstacles where necessary
        for y in range(0, mapdata.info.height):
            for x in range(0, mapdata.info.width):
                #Grid to Index:
                index = self.grid_to_index(mapdata, (x, y))
                #Check if obstacle:
                if mapdata.data[index] > 0:
                    for ypad in range(-padding, padding):
                        for xpad in range(-padding, padding):
                            newX = x + xpad
                            newY = y + ypad
                            #Calculate cells that need the padding
                            newIndex = self.grid_to_index(mapdata, (newX, newY))
                            #print(mapdata.data[newIndex])
                            #if mapdata.data[newIndex] >= 0:
                            if(cspace.data[newIndex] != 100):
                                #Add Padding Obstacles
                                worldPt = self.grid_to_world(mapdata, (newX, newY))
                                #point = Point(x=worldPt.x, y=worldPt.y)
                                newGridCells.cells.append(worldPt)
                                cspace.data[newIndex] = 100
                else:
                    #Add Empty Cells
                    worldPt = self.grid_to_world(mapdata, (x, y))
                    #point = Point(x=worldPt.x, y=worldPt.y)
                    if(cspace.data[index] == 0):
                        cspace.data[index] = mapdata.data[index]
        ## Create a GridCells message and publish it
        newGridCells.header = mapdata.header
        newGridCells.cell_width = mapdata.info.resolution
        newGridCells.cell_height = mapdata.info.resolution
        self.cspaceGridCells = newGridCells
        self.Cspace.publish(newGridCells)
        ## Return the C-space
        #print("Published CSpace")
        rospy.loginfo("Done w/ C-Space")
        self.cspaceholder = cspace
        return cspace
             
    def a_star(self, mapdata: OccupancyGrid, start: tuple[int, int], goal: tuple[int, int]) -> list[tuple[int, int]]:
        """
        
        """
        ### REQUIRED CREDIT
        rospy.loginfo("Executing A* from (%d,%d) to (%d,%d)" % (start[0], start[1], goal[0], goal[1]))
        pQueue = PriorityQueue()
        pQueue.put(start, 0)
        cameFrom = dict()
        costSoFar = dict()
        cameFrom[start] = None
        costSoFar[start] = 0
        #wave = GridCells()
        #wave.header = mapdata.header
        #wave.cell_height = mapdata.info.resolution
        #wave.cell_width = mapdata.info.resolution
        curr = start
        while not pQueue.empty():
            current = pQueue.get()
        
            if current == goal:
                curr = goal
                break
            #neighbors = PathPlanner.neighbors_of_4(mapdata, current)
            for next in PathPlanner.neighbors_of_8(mapdata, current): #8
                if next in PathPlanner.neighbors_of_4(mapdata, current):
                    newCost = costSoFar[current] + 1
                else:
                    newCost = costSoFar[current] + 1.415

                if current != start:
                    prev_direction = (current[0] - cameFrom[current][0], current[1] - cameFrom[current][1])
                    next_direction = (next[0] - current[0], next[1] - current[1])

                    if prev_direction != next_direction:
                        newCost += 0.01

                    if len(PathPlanner.neighbors_of_8(mapdata, next)) <= 7:
                        newCost += 10
                #worldPt = self.grid_to_world(mapdata, next)
                #point = Point(x=worldPt.x, y=worldPt.y)
                #wave.cells.append(point)
                #self.Wave.publish(wave)
                if next not in costSoFar or newCost < costSoFar[next]:
                    #index = self.grid_to_index(mapdata, next[0], next[1])
                    costSoFar[next] = newCost
                    priority = newCost + PathPlanner.euclidean_distance(goal, next)
                    #rospy.loginfo(priority)
                    pQueue.put(next, priority)
                    cameFrom[next] = current
        
        
        if(curr == start):
            rospy.loginfo("No Path Found")
            return []
        #self.Wave.publish(wave)
        print("Finished Astar")

        curr = goal
        path = []
        #print("Here 3")
        #print(cameFrom)
        # reconstruct path from camefrom
        while(curr != start):
            path.append(curr)
            curr = cameFrom[curr]
        path.append(start)
        path.reverse()
        #print("Here 2")
        return path
       
    def path_to_message(self, mapdata: OccupancyGrid, path: list[tuple[int, int]]) -> Path:
        """
        Takes a path on the grid and returns a Path message.
        :param path [[(int,int)]] The path on the grid (a list of tuples)
        :return     [Path]        A Path message (the coordinates are expressed in the world)
        """
        ### REQUIRED CREDIT
        rospy.loginfo("Returning a Path message")
        pathMsg = Path()
        pathMsg.header = mapdata.header
        for i in range(0, len(path)):
            worldPts = self.grid_to_world(mapdata, path[i])
            point = PoseStamped()
            point.pose.position = worldPts
            pathMsg.poses.append(point)
        return pathMsg

    def plan_path(self, msg) -> Path:
        """
        Plans a path between the start and goal locations in the requested.
        Internally uses A* to plan the optimal path.
        :param req 
        """
        start = PathPlanner.world_to_grid(self.cspaceholder, msg.start.pose.position)
        ## Request the map
        ## Calculate the frontiers and publish`` them
        #print("pp 520")
            #waypoints = PathPlanner.optimize_path2(path)
        rospy.loginfo("Finding Path Home")
        goal = PathPlanner.world_to_grid(self.cspaceholder, msg.goal.pose.position)
        path  = self.a_star(self.cspaceholder, start, goal)
            #waypoints = PathPlanner.optimize_path(path)
        


        ## Execute A*
        ## Path to go on
        
        ## Optimize waypoints
        
        ## Return a Path message
        return self.path_to_message(self.cspaceholder, path)
    
    def run(self):
        """
        Runs the node until Ctrl-C is pressed.
        """
        # map = PathPlanner.request_map()
        #cSp = self.calc_cspace(map, 1)
        rate = rospy.Rate(30)
        rospy.spin()

if __name__ == '__main__':
    PathPlanner().run()
