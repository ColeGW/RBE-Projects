#!/usr/bin/env python3

import rospy
import tf

if __name__ == '__main__':
    rospy.init_node('static_tf_broadcaster')

    broadcaster = tf.TransformBroadcaster()

    rate = rospy.Rate(100) 
    print("hello")
    broadcaster.sendTransform(
            (0.0, 0.0, 0.0),  
            (0.0, 0.0, 0.0, 1.0),  
            rospy.Time.now(),  
            "odom",
            "map"  
        )
    rate.sleep()
    # while not rospy.is_shutdown():
    #     broadcaster.sendTransform(
    #         (0.0, 0.0, 0.0),  
    #         (0.0, 0.0, 0.0, 1.0),  
    #         rospy.Time.now(), 
    #         "",  
    #         "map"  
    #     )


