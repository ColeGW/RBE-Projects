# Romi-32u4-utilities
 
Utilities for the Romi board with the ATmega32U4 chip. Includes several Pololu libraries plus a library that allows use of pin change interrupts.

More documentation to be added. 