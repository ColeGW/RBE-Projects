# DFRobotIRPosition
DFRobot's Positioning ir camera

 * file irPositionExample.cpp
 * brief DFRobot's Positioning ir camera
 * [Get the module here](http://www.dfrobot.com/index.php?route=product/product&product_id=1088)
 * This example get the four lightest positions of the IR sources.
 * [Connection and Diagram](http://www.dfrobot.com/wiki/index.php/Positioning_ir_camera#Connection_Diagram)
 *
 * Copyright	[DFRobot](http://www.dfrobot.com), 2016
 * Copyright	GNU Lesser General Public License
 *
 * author [Angelo](Angelo.qiao@dfrobot.com)
 * version  V1.0
 * date  2016-02-17
